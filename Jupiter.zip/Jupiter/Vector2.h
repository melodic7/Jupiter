#pragma once

#include <cmath>

namespace Vector2 {

    struct vec2 {

        double x = 0;
        double y = 0;

        vec2() {}

        vec2(double x, double y)
            : x(x), y(y) {}
    };

    inline vec2 Add(
        const vec2& a,
        const vec2& b
    ) {
        return vec2(
            a.x + b.x,
            a.y + b.y
        );
    }

    inline vec2 Subtract(
        const vec2& a,
        const vec2& b
    ) {
        return vec2(
            a.x - b.x,
            a.y - b.y
        );
    }

    inline vec2 Multiply(
        const vec2& a,
        double value
    ) {
        return vec2(
            a.x * value,
            a.y * value
        );
    }

    inline vec2 Divide(
        const vec2& a,
        double value
    ) {
        if (value == 0)
            return vec2();

        return vec2(
            a.x / value,
            a.y / value
        );
    }

    inline double Magnitude(
        const vec2& vector
    ) {
        return std::sqrt(
            vector.x * vector.x +
            vector.y * vector.y
        );
    }

    inline double Distance(
        const vec2& a,
        const vec2& b
    ) {
        double x = b.x - a.x;
        double y = b.y - a.y;

        return std::sqrt(
            x * x + y * y
        );
    }

    inline vec2 Normalize(
        const vec2& vector
    ) {
        double magnitude =
            Magnitude(vector);

        if (magnitude == 0)
            return vec2();

        return vec2(
            vector.x / magnitude,
            vector.y / magnitude
        );
    }

}