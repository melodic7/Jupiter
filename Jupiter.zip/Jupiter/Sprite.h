#pragma once

#include <string>
#include <vector>
#include <fstream>

namespace Sprite {

    struct Sprite {

        int Width = 0;
        int Height = 0;

        std::vector<std::vector<int>> Pixels;
    };

    inline Sprite Create(
        int width,
        int height,
        int color = 0
    ) {

        Sprite sprite;

        sprite.Width = width;
        sprite.Height = height;

        sprite.Pixels =
            std::vector<std::vector<int>>(
                height,
                std::vector<int>(
                    width,
                    color
                )
            );

        return sprite;
    }

    inline void SetPixel(
        Sprite& sprite,
        int x,
        int y,
        int color
    ) {

        if (x < 0 || y < 0)
            return;

        if (x >= sprite.Width ||
            y >= sprite.Height)
            return;

        sprite.Pixels[y][x] = color;
    }

    inline int GetPixel(
        const Sprite& sprite,
        int x,
        int y
    ) {

        if (x < 0 || y < 0)
            return 0;

        if (x >= sprite.Width ||
            y >= sprite.Height)
            return 0;

        return sprite.Pixels[y][x];
    }

    inline Sprite Load(
        const std::string& file
    ) {

        Sprite sprite;

        std::ifstream in(file.c_str());

        if (!in.is_open())
            return sprite;

        std::string line;

        while (std::getline(in, line)) {

            std::vector<int> row;

            for (std::size_t i = 0;
                 i < line.length();
                 ++i) {

                char c = line[i];

                if (c >= '0' && c <= '9') {
                    row.push_back(c - '0');
                }
            }

            if (!row.empty()) {
                sprite.Pixels.push_back(row);
            }
        }

        sprite.Height =
            static_cast<int>(
                sprite.Pixels.size()
            );

        if (sprite.Height == 0)
            return sprite;

        sprite.Width =
            static_cast<int>(
                sprite.Pixels[0].size()
            );

        // Make every row the same width.
        for (std::size_t y = 0;
             y < sprite.Pixels.size();
             ++y) {

            sprite.Pixels[y].resize(
                sprite.Width,
                0
            );
        }

        return sprite;
    }

}