#pragma once

#include <vector>

namespace Chunk {

    struct chunk {
        int x = 0;
        int y = 0;
        int width = 16;
        int height = 16;

        std::vector<std::vector<char>> tiles;

        chunk() {
            tiles = std::vector<std::vector<char>>(
                height,
                std::vector<char>(width, ' ')
            );
        }

        chunk(int x, int y, int width, int height)
            : x(x),
              y(y),
              width(width),
              height(height)
        {
            tiles = std::vector<std::vector<char>>(
                height,
                std::vector<char>(width, ' ')
            );
        }
    };

    inline void SetTile(
        chunk& c,
        int x,
        int y,
        char tile
    ) {
        if (x < 0 || y < 0)
            return;

        if (x >= c.width || y >= c.height)
            return;

        c.tiles[y][x] = tile;
    }

    inline char GetTile(
        const chunk& c,
        int x,
        int y
    ) {
        if (x < 0 || y < 0)
            return ' ';

        if (x >= c.width || y >= c.height)
            return ' ';

        return c.tiles[y][x];
    }

    inline void Fill(
        chunk& c,
        char tile
    ) {
        for (int y = 0; y < c.height; ++y) {
            for (int x = 0; x < c.width; ++x) {
                c.tiles[y][x] = tile;
            }
        }
    }

}