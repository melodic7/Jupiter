#pragma once

#include "Time.h"
#include "Input.h"

namespace GameLoop {

    typedef void (*Function)();

    struct loop {
        bool running = true;

        Function Start = 0;
        Function Update = 0;
        Function Render = 0;
        Function Shutdown = 0;
    };

    inline void Stop(loop& game) {
        game.running = false;
    }

    inline void Run(loop& game) {

        if (game.Start) {
            game.Start();
        }

        while (game.running) {

            Time::Update();

            Input::Update();

            if (game.Update) {
                game.Update();
            }

            if (game.Render) {
                game.Render();
            }

        }

        if (game.Shutdown) {
            game.Shutdown();
        }
    }

}