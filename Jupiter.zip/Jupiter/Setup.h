#pragma once

#include "Input.h"
#include "Renderer.h"

namespace Setup {

    inline bool& Initialized() {
        static bool initialized = false;
        return initialized;
    }

    inline void Initialize(
        int width = 80,
        int height = 24
    ) {

        if (Initialized())
            return;

        Renderer::Initialize(
            width,
            height
        );

        Input::Initialize();

        Initialized() = true;
    }

    inline void Shutdown() {

        if (!Initialized())
            return;

        Input::Shutdown();
        Renderer::Shutdown();

        Initialized() = false;
    }

}