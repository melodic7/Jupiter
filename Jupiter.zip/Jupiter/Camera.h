#pragma once

#include "Vector2.h"

namespace Camera {

    struct camera {
        Vector2::vec2 position;
        int width = 80;
        int height = 24;

        camera() {}

        camera(int width, int height)
            : width(width), height(height) {}
    };

    inline void SetPosition(
        camera& cam,
        double x,
        double y
    ) {
        cam.position.x = x;
        cam.position.y = y;
    }

    inline Vector2::vec2 WorldToScreen(
        const camera& cam,
        Vector2::vec2 worldPosition
    ) {
        return {
            worldPosition.x - cam.position.x,
            worldPosition.y - cam.position.y
        };
    }

    inline Vector2::vec2 ScreenToWorld(
        const camera& cam,
        Vector2::vec2 screenPosition
    ) {
        return {
            screenPosition.x + cam.position.x,
            screenPosition.y + cam.position.y
        };
    }

    inline bool IsVisible(
        const camera& cam,
        Vector2::vec2 position
    ) {
        return position.x >= cam.position.x &&
               position.x < cam.position.x + cam.width &&
               position.y >= cam.position.y &&
               position.y < cam.position.y + cam.height;
    }

}