#pragma once

#include "Rect.h"
#include "Vector2.h"

namespace Collision {

    inline bool RectVsRect(
        const Rect::rect& a,
        const Rect::rect& b
    ) {
        return Rect::Intersects(a, b);
    }

    inline bool PointVsRect(
        Vector2::vec2 point,
        const Rect::rect& rect
    ) {
        return Rect::Contains(rect, point);
    }

    inline bool PointVsPoint(
        Vector2::vec2 a,
        Vector2::vec2 b
    ) {
        return a.x == b.x && a.y == b.y;
    }

    inline bool CircleVsCircle(
        Vector2::vec2 a,
        double radiusA,
        Vector2::vec2 b,
        double radiusB
    ) {
        return Vector2::Distance(a, b) <= radiusA + radiusB;
    }

}