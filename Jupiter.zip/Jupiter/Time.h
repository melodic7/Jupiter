#pragma once

#include <chrono>
#include <thread>

namespace Time {

    inline double& Delta() {
        static double delta = 0.0;
        return delta;
    }

    inline double& Total() {
        static double total = 0.0;
        return total;
    }

    inline std::chrono::steady_clock::time_point& LastTime() {
        static std::chrono::steady_clock::time_point last =
            std::chrono::steady_clock::now();

        return last;
    }

    inline void Update() {

        std::chrono::steady_clock::time_point current =
            std::chrono::steady_clock::now();

        std::chrono::duration<double> difference =
            current - LastTime();

        LastTime() = current;

        Delta() = difference.count();

        // Prevent massive delta times if the program pauses.
        if (Delta() > 0.25) {
            Delta() = 0.25;
        }

        Total() += Delta();
    }

    inline double DeltaTime() {
        return Delta();
    }

    inline double TimeSinceStart() {
        return Total();
    }

    inline void Sleep(double milliseconds) {
        std::this_thread::sleep_for(
            std::chrono::duration<double, std::milli>(
                milliseconds
            )
        );
    }

}