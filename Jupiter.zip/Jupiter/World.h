#pragma once
#include <vector>

namespace World {
    struct world {
        int width = 0;
        int height = 0;
        std::vector<std::vector<char>> world_data;

        world() {}
        world(int width, int height) : width(width), height(height) {
            world_data = std::vector<std::vector<char>>(
                height, 
                std::vector<char>(width, ' ')
            );
        }
    };

    // FIXED: Added the 'world' return type after 'inline'
    inline world worldCreate( int width, int height, char defaultTile = ' ' ) {
        world result( width, height );
        for (int y = 0; y < height; ++y) {
            for (int x = 0; x < width; ++x) {
                result.world_data[y][x] = defaultTile;
            }
        }
        return result;
    }

    inline void SetTile( world& map, int x, int y, char tile ) {
        if (x < 0 || y < 0) return;
        if (x >= map.width || y >= map.height) return;
        map.world_data[y][x] = tile;
    }

    inline char GetTile( const world& map, int x, int y ) {
        if (x < 0 || y < 0) return ' ';
        if (x >= map.width || y >= map.height) return ' ';
        return map.world_data[y][x];
    }
}