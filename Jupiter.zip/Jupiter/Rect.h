#pragma once

#include "Vector2.h"

namespace Rect {

    struct rect {
        double x = 0;
        double y = 0;
        double width = 0;
        double height = 0;

        rect() {}

        rect(double x, double y, double width, double height)
            : x(x), y(y), width(width), height(height) {}
    };

    inline bool Contains(const rect& r, Vector2::vec2 point) {
        return point.x >= r.x &&
               point.x <= r.x + r.width &&
               point.y >= r.y &&
               point.y <= r.y + r.height;
    }

    inline bool Intersects(const rect& a, const rect& b) {
        return a.x < b.x + b.width &&
               a.x + a.width > b.x &&
               a.y < b.y + b.height &&
               a.y + a.height > b.y;
    }

    inline Vector2::vec2 Center(const rect& r) {
        return {
            r.x + r.width / 2.0,
            r.y + r.height / 2.0
        };
    }

}