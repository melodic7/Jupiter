#pragma once

#include <termios.h>
#include <unistd.h>
#include <fcntl.h>

namespace Input {

    // ---------------------------------------------------------
    // Terminal state
    // ---------------------------------------------------------

    inline termios& OriginalTerminal()
    {
        static termios terminal;
        return terminal;
    }

    inline bool& Initialized()
    {
        static bool initialized = false;
        return initialized;
    }

    // ---------------------------------------------------------
    // Current-frame key states
    // ---------------------------------------------------------

    inline bool* KeyStates()
    {
        static bool states[256] = {};
        return states;
    }

    inline bool* PressedStates()
    {
        static bool states[256] = {};
        return states;
    }

    // ---------------------------------------------------------
    // Initialize
    // ---------------------------------------------------------

    inline void Initialize()
    {
        if (Initialized())
            return;

        tcgetattr(STDIN_FILENO, &OriginalTerminal());

        termios raw = OriginalTerminal();

        // Disable canonical mode and echo
        raw.c_lflag &= ~(ICANON | ECHO);

        // Read immediately instead of waiting for Enter
        raw.c_cc[VMIN] = 0;
        raw.c_cc[VTIME] = 0;

        tcsetattr(STDIN_FILENO, TCSANOW, &raw);

        // Make stdin non-blocking
        int flags = fcntl(STDIN_FILENO, F_GETFL, 0);
        fcntl(STDIN_FILENO, F_SETFL, flags | O_NONBLOCK);

        Initialized() = true;
    }

    // ---------------------------------------------------------
    // Shutdown
    // ---------------------------------------------------------

    inline void Shutdown()
    {
        if (!Initialized())
            return;

        tcsetattr(
            STDIN_FILENO,
            TCSANOW,
            &OriginalTerminal()
        );

        Initialized() = false;
    }

    // ---------------------------------------------------------
    // Update
    // ---------------------------------------------------------

    inline void Update()
    {
        Initialize();

        // Clear the previous frame's input
        for (int i = 0; i < 256; ++i)
        {
            KeyStates()[i] = false;
            PressedStates()[i] = false;
        }

        char key;

        // Read every key currently waiting in stdin
        while (read(STDIN_FILENO, &key, 1) > 0)
        {
            unsigned char index =
                static_cast<unsigned char>(key);

            KeyStates()[index] = true;
            PressedStates()[index] = true;
        }
    }

    // ---------------------------------------------------------
    // IsKeyDown
    //
    // True if this key was received during this frame.
    // ---------------------------------------------------------

    inline bool IsKeyDown(char key)
    {
        return KeyStates()[
            static_cast<unsigned char>(key)
        ];
    }

    // ---------------------------------------------------------
    // IsKeyPressed
    //
    // True if this key was received during this frame.
    // ---------------------------------------------------------

    inline bool IsKeyPressed(char key)
    {
        return PressedStates()[
            static_cast<unsigned char>(key)
        ];
    }

    // ---------------------------------------------------------
    // IsKeyReleased
    //
    // Terminal input doesn't provide reliable key-up events.
    // Kept for API compatibility.
    // ---------------------------------------------------------

    inline bool IsKeyReleased(char key)
    {
        (void)key;
        return false;
    }

    // ---------------------------------------------------------
    // GetKey
    // ---------------------------------------------------------

    inline char GetKey()
    {
        char key;

        if (read(STDIN_FILENO, &key, 1) > 0)
            return key;

        return '\0';
    }

}