#pragma once

#include <random>

namespace Random {

    inline std::mt19937& Engine() {
        static std::mt19937 engine(
            static_cast<unsigned int>(
                std::random_device()()
            )
        );

        return engine;
    }

    inline int Int(int minimum, int maximum) {
        if (minimum > maximum) {
            int temp = minimum;
            minimum = maximum;
            maximum = temp;
        }

        std::uniform_int_distribution<int> distribution(
            minimum,
            maximum
        );

        return distribution(Engine());
    }

    inline double Float(double minimum, double maximum) {
        if (minimum > maximum) {
            double temp = minimum;
            minimum = maximum;
            maximum = temp;
        }

        std::uniform_real_distribution<double> distribution(
            minimum,
            maximum
        );

        return distribution(Engine());
    }

    inline bool Bool() {
        return Int(0, 1) == 1;
    }

}