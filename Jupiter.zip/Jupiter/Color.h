#pragma once

namespace Color {

    enum color {
        Transparent = 0,

        Black = 1,
        Red = 2,
        Green = 3,
        Yellow = 4,
        Blue = 5,
        Magenta = 6,
        Cyan = 7,
        White = 8,

        BrightBlack = 9,
        BrightRed = 10,
        BrightGreen = 11,
        BrightYellow = 12,
        BrightBlue = 13,
        BrightMagenta = 14,
        BrightCyan = 15,
        BrightWhite = 16
    };

}