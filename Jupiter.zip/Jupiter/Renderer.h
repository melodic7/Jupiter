#pragma once

#include <iostream>
#include <vector>
#include <string>

#include "Color.h"
#include "Sprite.h"

namespace Renderer {

    struct Pixel {
        std::string character;
        int color;

        Pixel()
            : character(" "),
              color(Color::White) {}

        Pixel(const std::string& character, int color)
            : character(character),
              color(color) {}
    };

    inline int& Width() {
        static int width = 80;
        return width;
    }

    inline int& Height() {
        static int height = 24;
        return height;
    }

    inline std::vector<Pixel>& Buffer() {
        static std::vector<Pixel> buffer;

        if (buffer.empty()) {
            buffer.resize(Width() * Height());
        }

        return buffer;
    }

    inline const char* GetAnsiColor(int color) {

        switch (color) {

            case Color::Black:
                return "\033[30m";

            case Color::Red:
                return "\033[31m";

            case Color::Green:
                return "\033[32m";

            case Color::Yellow:
                return "\033[33m";

            case Color::Blue:
                return "\033[34m";

            case Color::Magenta:
                return "\033[35m";

            case Color::Cyan:
                return "\033[36m";

            case Color::White:
                return "\033[37m";

            case Color::BrightBlack:
                return "\033[90m";

            case Color::BrightRed:
                return "\033[91m";

            case Color::BrightGreen:
                return "\033[92m";

            case Color::BrightYellow:
                return "\033[93m";

            case Color::BrightBlue:
                return "\033[94m";

            case Color::BrightMagenta:
                return "\033[95m";

            case Color::BrightCyan:
                return "\033[96m";

            case Color::BrightWhite:
                return "\033[97m";

            default:
                return "\033[0m";
        }
    }

    inline void Initialize(
        int width = 80,
        int height = 24
    ) {

        Width() = width;
        Height() = height;

        Buffer().clear();

        Buffer().resize(
            Width() * Height()
        );

        std::cout << "\033[2J";
        std::cout << "\033[H";
        std::cout << "\033[?25l";
        std::cout.flush();
    }

    inline void Shutdown() {

        std::cout << "\033[0m";
        std::cout << "\033[?25h";
        std::cout << "\033[2J";
        std::cout << "\033[H";
        std::cout.flush();
    }

    inline void Clear(
        const std::string& character = " ",
        int color = Color::White
    ) {

        for (std::size_t i = 0;
             i < Buffer().size();
             ++i) {

            Buffer()[i] = Pixel(
                character,
                color
            );
        }
    }

    inline void SetPixel(
        int x,
        int y,
        const std::string& character,
        int color = Color::White
    ) {

        if (x < 0 || y < 0)
            return;

        if (x >= Width() || y >= Height())
            return;

        Buffer()[
            y * Width() + x
        ] = Pixel(
            character,
            color
        );
    }

    inline Pixel GetPixel(
        int x,
        int y
    ) {

        if (x < 0 || y < 0 ||
            x >= Width() ||
            y >= Height()) {

            return Pixel();
        }

        return Buffer()[
            y * Width() + x
        ];
    }

    inline void DrawSprite(
        const Sprite::Sprite& sprite,
        int x,
        int y
    ) {

        for (int row = 0;
             row < sprite.Height;
             ++row) {

            for (int col = 0;
                 col < sprite.Width;
                 ++col) {

                int pixel =
                    sprite.Pixels[row][col];

                // 0 = transparent
                if (pixel == 0)
                    continue;

                SetPixel(
                    x + col,
                    y + row,
                    "█",
                    pixel
                );
            }
        }
    }

    inline void DrawChar(
        int x,
        int y,
        const std::string& character,
        int color = Color::White
    ) {

        SetPixel(
            x,
            y,
            character,
            color
        );
    }

    inline void DrawString(
        int x,
        int y,
        const std::string& text,
        int color = Color::White
    ) {

        for (std::size_t i = 0;
             i < text.length();
             ++i) {

            SetPixel(
                x + static_cast<int>(i),
                y,
                std::string(1, text[i]),
                color
            );
        }
    }

    inline void Present() {

        std::cout << "\033[H";

        int lastColor = -1;

        for (int y = 0;
             y < Height();
             ++y) {

            for (int x = 0;
                 x < Width();
                 ++x) {

                const Pixel& pixel =
                    Buffer()[y * Width() + x];

                if (pixel.color != lastColor) {

                    std::cout <<
                        GetAnsiColor(pixel.color);

                    lastColor =
                        pixel.color;
                }

                std::cout <<
                    pixel.character;
            }

            if (y < Height() - 1)
                std::cout << '\n';
        }

        std::cout << "\033[0m";
        std::cout.flush();
    }

    inline void ResetColor() {
        std::cout << "\033[0m";
    }

}