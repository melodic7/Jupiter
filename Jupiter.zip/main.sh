#g++ -std=c++11 Game.cpp -o JupiterGame
#./JupiterGame